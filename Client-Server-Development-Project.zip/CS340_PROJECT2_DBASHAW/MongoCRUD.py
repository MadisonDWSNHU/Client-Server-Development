from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib

class MongoCRUD(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, DB, COL, HOST, PORT = 32223):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        #
        # Initialize Connection
        self.client = MongoClient('mongodb://%s:' % (username) + urllib.parse.quote(password) + '@%s:%d' % (HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, doc=None):
        if doc is not None and len(doc) != 0:
            return self.database.animals.insert(doc)  # data should be dictionary
        else:
            raise Exception("Error: data creation failed.")

# Create method to implement the R in CRUD.
    def read(self, doc=None):
        return self.database.animals.find(doc)
        
# Create method to implement the U in CRUD.
    def update(self, doc, newValue):
        if doc is not None and len(doc) != 0:
            return self.database.animals.update(doc, newValue)
        else:
            raise Exception("Error: data failed to update.")

# Create method to implement the D in CRUD.
    def delete(self, doc):
        if doc is not None and len(doc) != 0:
            return self.database.animals.delete_many(doc)
        else:
            raise Exception("Error: data failed to delete.")